package examples.pubhub.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import examples.pubhub.dao.TagDAO;
import examples.pubhub.dao.TagDaoImpl;
import examples.pubhub.model.Tag;

@WebServlet("/AddTag")
public class AddTagServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		boolean isSuccess = false;
		String isbn13 = req.getParameter("isbn13");
		String tagname = req.getParameter("tag");
		
		TagDAO dao = new TagDaoImpl();
		
		Tag tag = new Tag(isbn13, tagname.toLowerCase());
		req.setAttribute("tag", tag);
		isSuccess = dao.addTagToBook(tag);
		
		if (isSuccess) {
			req.getSession().setAttribute("message", "Tag added");
			req.getSession().setAttribute("messageClass", "alert-success");
			resp.sendRedirect("ViewBookDetails?isbn13=" + isbn13);
		}
		else {
			req.getSession().setAttribute("message", "Tag \"" + tagname + "\" already exists");
			req.getSession().setAttribute("messageClass", "alert-danger");
			resp.sendRedirect("ViewBookDetails?isbn13=" + isbn13);
		}
	}
		
}

