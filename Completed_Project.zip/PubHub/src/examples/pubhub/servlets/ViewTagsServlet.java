package examples.pubhub.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import examples.pubhub.dao.TagDAO;
import examples.pubhub.dao.TagDaoImpl;
import examples.pubhub.model.Book;
import examples.pubhub.model.Tag;

/**
 * Servlet implementation class ViewTagsServlet
 */
@WebServlet("/ViewTags")
public class ViewTagsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {	
		
		TagDAO dao = new TagDaoImpl();
		List<String> tags = dao.getAllTags();
		
		req.setAttribute("tags", tags);
		
		req.getRequestDispatcher("viewTags.jsp").forward(req, resp);
		
	}
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {	
		String searchtag = req.getParameter("searchtag");
		
		TagDAO dao = new TagDaoImpl();
		List<Book> booklist = dao.getBooksWithTag(searchtag);
		List<String> bookstring = new ArrayList();
		
		for (Book bb : booklist) {
			bookstring.add(bb.getTitle());
		}
	
		req.setAttribute("titletag", searchtag);
		req.setAttribute("booklist", booklist);
	
		req.getRequestDispatcher("taggedBooks.jsp").forward(req, resp);
		
	}
}