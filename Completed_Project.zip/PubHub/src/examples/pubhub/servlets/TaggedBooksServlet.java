package examples.pubhub.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import examples.pubhub.dao.TagDAO;
import examples.pubhub.dao.TagDaoImpl;
import examples.pubhub.model.Book;

/**
 * Servlet implementation class TaggedBooksServlet
 */
@WebServlet("/books")
public class TaggedBooksServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String tag = req.getParameter("tag");
		
		TagDAO tao = new TagDaoImpl();
		List<Book> booklist = tao.getBooksWithTag(tag);
		
		req.getSession().setAttribute("titletag", tag);
		req.getSession().setAttribute("booklist", booklist);
		
		req.getRequestDispatcher("taggedBooks.jsp").forward(req, resp);
		
	}
}
