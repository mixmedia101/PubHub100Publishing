package examples.pubhub.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import examples.pubhub.dao.TagDAO;
import examples.pubhub.dao.TagDaoImpl;
import examples.pubhub.model.Tag;

@WebServlet("/DeleteTag")
public class DeleteTagServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String isbn13 = req.getParameter("isbn13");
		
		TagDAO dao = new TagDaoImpl();
		
		String[] delete = req.getParameterValues("deletetag");
		
		if (delete == null) {
			req.getSession().setAttribute("message", "No tags selected");
			req.getSession().setAttribute("messageClass", "alert-danger");
			resp.sendRedirect("ViewBookDetails?isbn13=" + isbn13);
		}
		
		List<String> deleteList = new ArrayList<String>();
	    for(String tt : delete) {deleteList.add(tt);}

		for (String t : deleteList) {
			Tag tag = new Tag(isbn13, t);
			
			dao.deleteTagFromBook(tag);
			}

			req.getSession().setAttribute("message", "Tags deleted");
			req.getSession().setAttribute("messageClass", "alert-success");
			resp.sendRedirect("ViewBookDetails?isbn13=" + isbn13);

			}
		}
