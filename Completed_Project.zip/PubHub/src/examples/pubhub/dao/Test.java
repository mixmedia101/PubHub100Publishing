package examples.pubhub.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import examples.pubhub.model.Book;
import examples.pubhub.model.Tag;
import examples.pubhub.utilities.DAOUtilities;

public class Test extends Tag {

	public static String toString(Tag tag) {
		return String.format(tag.getTag());}
		
	public static void main(String[] args) {
		String isbn13 = "1111111111111";
		   TagDAO dao = new TagDaoImpl();
		    
/*		    TagDAO tao = new TagDaoImpl();
			String tags = tao.getTagsForBook(isbn13);
			
			System.out.println(tags);*/
		   List<Book> b = dao.getBooksWithTag("tags");
		   System.out.println(b);
		    }
		}
	