package examples.pubhub.dao;

import java.util.List;

import examples.pubhub.model.Book;
import examples.pubhub.model.Tag;

public interface TagDAO {

	public boolean addTagToBook(Tag tag);			//AddTagServlet
	public boolean deleteTagFromBook(Tag tag);		//DeleteTagServlet
	
	public List<Tag> getTagsForBook(String isbn13);//ViewBookDetailsServlet
	public List<Book> getBooksWithTag(String tag);	//TaggedBooksServlet
	public List<String> getAllTags();					//ViewTagsServlet
}
