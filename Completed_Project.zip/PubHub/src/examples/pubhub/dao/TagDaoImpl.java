package examples.pubhub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.resource.cci.ResultSet;
import java.util.stream.Collectors;

import examples.pubhub.model.Book;
import examples.pubhub.model.Tag;
import examples.pubhub.utilities.DAOUtilities;

public class TagDaoImpl implements TagDAO {

	Connection conn = null;
	PreparedStatement stmt = null;
	
	public String toString(Tag tag) {
		return String.format(tag.getTag());}
	
	@Override
	public boolean addTagToBook(Tag tag) {
		try {
			conn = DAOUtilities.getConnection();
			String sql = "INSERT INTO book_tags VALUES (?,?)";
			stmt = conn.prepareStatement(sql);
			
			stmt.setString(1, tag.getIsbn13());
			stmt.setString(2, tag.getTag());
			
			if (stmt.executeUpdate() != 0)
				return true;
			else
				return false;
			}
		catch (SQLException e) {
			e.printStackTrace();
			return false;}
		finally {
			closeResources();
		}
	}

	@Override
	public boolean deleteTagFromBook(Tag tag) {
		try {
			conn = DAOUtilities.getConnection();
			String sql = "DELETE FROM book_tags WHERE (isbn_13 = ? AND tag_name = ?)";
			stmt = conn.prepareStatement(sql);
			
			stmt.setString(1, tag.getIsbn13());
			stmt.setString(2, tag.getTag());
			
			if (stmt.executeUpdate() != 0) 
				return true;
			else 
				return false;
			}
		catch (SQLException e) {
			e.printStackTrace();
		return false;}
		finally {
			closeResources();
		}
	}
	
	@Override
	public List<Tag> getTagsForBook(String isbn13) {
		List<Tag> taglist = new ArrayList<Tag>();
		
		try {
			conn = DAOUtilities.getConnection();
			String sql = "SELECT * FROM book_tags JOIN books USING(isbn_13) WHERE isbn_13 = ?";
			stmt = conn.prepareStatement(sql);
		
			stmt.setString(1, isbn13);
			
			java.sql.ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				Tag tag = new Tag();
				
				tag.setIsbn13(rs.getString("isbn_13"));
				tag.setTag(rs.getString("tag_name"));
				
				taglist.add(tag);
			}

		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			closeResources();
		}
		return taglist;
	}
	
	@Override
	public List<Book> getBooksWithTag(String tag) {
		List<Book> b = new ArrayList<>();
		List<Book> books = new ArrayList<>();
		
		try {
			conn = DAOUtilities.getConnection();
			String sql = "SELECT DISTINCT title, author, publish_date, price, content, books.isbn_13 FROM book_tags JOIN books USING(isbn_13) WHERE tag_name LIKE ?";
			stmt = conn.prepareStatement(sql);
		
			stmt.setString(1, "%" + tag + "%");
			
			java.sql.ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				Book book = new Book();
				
				book.setIsbn13(rs.getString("isbn_13"));
				book.setTitle(rs.getString("title"));
				book.setAuthor(rs.getString("author"));
				book.setPublishDate(rs.getDate("publish_date").toLocalDate());
				book.setPrice(rs.getDouble("price"));
				book.setContent(rs.getBytes("content"));
				
				b.add(book);
			}
			books = b.stream().distinct().collect(Collectors.toList());
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			closeResources();
		}
		return books;
	}
	
	@Override
	public List<String> getAllTags() {
		List<String> tags = new ArrayList<>();
		
		try {
			conn = DAOUtilities.getConnection();
			String sql = "SELECT tag_name, COUNT(tag_name) FROM book_tags GROUP BY tag_name";
			stmt = conn.prepareStatement(sql);
			
			java.sql.ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				tags.add(rs.getString("tag_name"));
				
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			closeResources();
		}
		return tags;
	}
	
	private void closeResources() {
		try {
			if (stmt != null)
				stmt.close();
		} catch (SQLException e) {
			System.out.println("Could not close statement!");
			e.printStackTrace();
		}
		
		try {
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			System.out.println("Could not close connection!");
			e.printStackTrace();
		}
	}
}
